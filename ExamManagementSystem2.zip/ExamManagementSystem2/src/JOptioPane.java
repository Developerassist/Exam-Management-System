/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Deep Karmur
 */
class JOptioPane {

    static int showConfirmDialog(Object object, String do_you_really_want_to_Exit_the_Applicatio, String select, int YES_NO_OPTION) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
